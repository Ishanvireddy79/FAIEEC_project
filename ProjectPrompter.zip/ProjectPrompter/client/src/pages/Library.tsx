import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Book as BookType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  BookOpen,
  Search,
  Plus,
  Star,
  Trash2,
  BookMarked,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Library() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterGenre, setFilterGenre] = useState<string>("all");
  const [isAddBookOpen, setIsAddBookOpen] = useState(false);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    description: "",
    genre: "",
    content: "",
    coverImageUrl: "",
    publishedYear: new Date().getFullYear(),
    totalPages: 0,
  });

  // Fetch books with progress and favorites
  const { data: booksData, isLoading: booksLoading } = useQuery<{
    books: (BookType & {
      progress?: { currentPage: number; progressPercentage: number; isCompleted: boolean };
      isFavorite: boolean;
    })[];
  }>({
    queryKey: ["/api/library"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Add book mutation
  const addBookMutation = useMutation({
    mutationFn: async (book: typeof newBook) => {
      return await apiRequest("POST", "/api/books", book);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      setIsAddBookOpen(false);
      setNewBook({
        title: "",
        author: "",
        description: "",
        genre: "",
        content: "",
        coverImageUrl: "",
        publishedYear: new Date().getFullYear(),
        totalPages: 0,
      });
      toast({
        title: "Success",
        description: "Book added to your library",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add book",
        variant: "destructive",
      });
    },
  });

  // Delete book mutation
  const deleteBookMutation = useMutation({
    mutationFn: async (bookId: string) => {
      return await apiRequest("DELETE", `/api/books/${bookId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      toast({
        title: "Success",
        description: "Book deleted from your library",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete book",
        variant: "destructive",
      });
    },
  });

  // Toggle favorite mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ bookId, isFavorite }: { bookId: string; isFavorite: boolean }) => {
      if (isFavorite) {
        return await apiRequest("DELETE", `/api/favorites/${bookId}`, {});
      } else {
        return await apiRequest("POST", "/api/favorites", { bookId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive",
      });
    },
  });

  const books = booksData?.books || [];

  // Filter books
  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = filterGenre === "all" || book.genre === filterGenre;
    return matchesSearch && matchesGenre;
  });

  // Get unique genres
  const genres = ["all", ...new Set(books.map((book) => book.genre).filter(Boolean))];

  const handleAddBook = () => {
    if (!newBook.title || !newBook.author || !newBook.content) {
      toast({
        title: "Error",
        description: "Please fill in required fields (title, author, content)",
        variant: "destructive",
      });
      return;
    }
    addBookMutation.mutate(newBook);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">My Library</h1>
          <p className="text-muted-foreground">
            {books.length} {books.length === 1 ? "book" : "books"} in your collection
          </p>
        </div>
        <Dialog open={isAddBookOpen} onOpenChange={setIsAddBookOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="min-h-10" data-testid="button-add-book">
              <Plus className="w-5 h-5 mr-2" />
              Add Book
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Book</DialogTitle>
              <DialogDescription>
                Add a new book to your personal library
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={newBook.title}
                  onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                  placeholder="Enter book title"
                  data-testid="input-book-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="author">Author *</Label>
                <Input
                  id="author"
                  value={newBook.author}
                  onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                  placeholder="Enter author name"
                  data-testid="input-book-author"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="genre">Genre</Label>
                <Input
                  id="genre"
                  value={newBook.genre}
                  onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })}
                  placeholder="e.g., Fiction, Non-fiction, Science"
                  data-testid="input-book-genre"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="coverImageUrl">Cover Image URL</Label>
                <Input
                  id="coverImageUrl"
                  value={newBook.coverImageUrl}
                  onChange={(e) => setNewBook({ ...newBook, coverImageUrl: e.target.value })}
                  placeholder="https://example.com/cover.jpg"
                  data-testid="input-book-cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="publishedYear">Published Year</Label>
                  <Input
                    id="publishedYear"
                    type="number"
                    value={newBook.publishedYear}
                    onChange={(e) => setNewBook({ ...newBook, publishedYear: parseInt(e.target.value) || 0 })}
                    data-testid="input-book-year"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="totalPages">Total Pages</Label>
                  <Input
                    id="totalPages"
                    type="number"
                    value={newBook.totalPages}
                    onChange={(e) => setNewBook({ ...newBook, totalPages: parseInt(e.target.value) || 0 })}
                    data-testid="input-book-pages"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newBook.description}
                  onChange={(e) => setNewBook({ ...newBook, description: e.target.value })}
                  placeholder="Brief description of the book"
                  rows={3}
                  data-testid="input-book-description"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">Content *</Label>
                <Textarea
                  id="content"
                  value={newBook.content}
                  onChange={(e) => setNewBook({ ...newBook, content: e.target.value })}
                  placeholder="Paste the full book content here..."
                  rows={10}
                  data-testid="input-book-content"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddBookOpen(false)}
                data-testid="button-cancel-add"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddBook}
                disabled={addBookMutation.isPending}
                data-testid="button-submit-book"
              >
                {addBookMutation.isPending ? "Adding..." : "Add Book"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search by title or author..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-books"
          />
        </div>
        <Select value={filterGenre} onValueChange={setFilterGenre}>
          <SelectTrigger className="w-full sm:w-48" data-testid="select-genre-filter">
            <SelectValue placeholder="All Genres" />
          </SelectTrigger>
          <SelectContent>
            {genres.map((genre) => (
              <SelectItem key={genre} value={genre} data-testid={`option-genre-${genre}`}>
                {genre === "all" ? "All Genres" : genre}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Books Grid */}
      {booksLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {[...Array(10)].map((_, i) => (
            <Card key={i} className="border-card-border">
              <CardContent className="p-0">
                <Skeleton className="aspect-[2/3] w-full rounded-t-md" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <BookOpen className="w-16 h-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">
            {searchQuery || filterGenre !== "all" ? "No books found" : "Your library is empty"}
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            {searchQuery || filterGenre !== "all"
              ? "Try adjusting your search or filter"
              : "Start building your digital library by adding your first book"}
          </p>
          {!searchQuery && filterGenre === "all" && (
            <Button onClick={() => setIsAddBookOpen(true)} data-testid="button-add-first-book">
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Book
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {filteredBooks.map((book) => (
            <Card
              key={book.id}
              className="border-card-border hover-elevate active-elevate-2 cursor-pointer group overflow-visible"
              data-testid={`card-book-${book.id}`}
            >
              <CardContent className="p-0">
                <div
                  className="relative aspect-[2/3] bg-muted rounded-t-md overflow-hidden"
                  onClick={() => navigate(`/reader/${book.id}`)}
                >
                  {book.coverImageUrl ? (
                    <img
                      src={book.coverImageUrl}
                      alt={book.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-muted-foreground" />
                    </div>
                  )}
                  <Button
                    size="icon"
                    variant="secondary"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavoriteMutation.mutate({ bookId: book.id, isFavorite: book.isFavorite });
                    }}
                    data-testid={`button-favorite-${book.id}`}
                  >
                    <Star
                      className={`w-4 h-4 ${book.isFavorite ? "fill-chart-4 text-chart-4" : ""}`}
                    />
                  </Button>
                </div>
                <div className="p-4 space-y-2" onClick={() => navigate(`/reader/${book.id}`)}>
                  <h3 className="font-semibold text-card-foreground line-clamp-2 leading-snug">
                    {book.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-1">{book.author}</p>
                  {book.genre && (
                    <Badge variant="secondary" className="text-xs">
                      {book.genre}
                    </Badge>
                  )}
                  {book.progress && (
                    <div className="space-y-1 pt-2">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>
                          {book.progress.isCompleted ? "Completed" : `${Math.round(book.progress.progressPercentage)}%`}
                        </span>
                        {!book.progress.isCompleted && (
                          <span>
                            Page {book.progress.currentPage}/{book.totalPages}
                          </span>
                        )}
                      </div>
                      <Progress value={book.progress.progressPercentage} className="h-1" />
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 min-h-8"
                  onClick={() => navigate(`/reader/${book.id}`)}
                  data-testid={`button-read-${book.id}`}
                >
                  <BookMarked className="w-4 h-4 mr-1" />
                  {book.progress?.currentPage ? "Continue" : "Read"}
                </Button>
                <Button
                  size="icon"
                  variant="outline"
                  className="min-h-8 w-8"
                  onClick={() => {
                    if (confirm("Are you sure you want to delete this book?")) {
                      deleteBookMutation.mutate(book.id);
                    }
                  }}
                  data-testid={`button-delete-${book.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
