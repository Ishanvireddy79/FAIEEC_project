import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Book, Bookmark as BookmarkType, ReadingProgress as ReadingProgressType, UserPreferences as UserPreferencesType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import {
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  Settings,
  X,
  ListOrdered,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const WORDS_PER_PAGE = 300;
const FONT_FAMILIES = [
  { value: "serif", label: "Merriweather (Serif)", className: "font-serif" },
  { value: "sans", label: "Inter (Sans-serif)", className: "font-sans" },
  { value: "mono", label: "JetBrains Mono", className: "font-mono" },
];
const LINE_SPACINGS = [
  { value: "compact", label: "Compact", className: "leading-normal" },
  { value: "normal", label: "Normal", className: "leading-relaxed" },
  { value: "relaxed", label: "Relaxed", className: "leading-loose" },
];
const THEMES = [
  { value: "white", label: "White", bgClass: "bg-background", textClass: "text-foreground" },
  { value: "sepia", label: "Sepia", bgClass: "bg-[#f4ecd8] dark:bg-[#3d3529]", textClass: "text-[#5f4b32] dark:text-[#d4c5a9]" },
  { value: "dark", label: "Dark", bgClass: "bg-card", textClass: "text-card-foreground" },
  { value: "black", label: "Black", bgClass: "bg-black", textClass: "text-gray-100" },
];
const MARGINS = [
  { value: "narrow", label: "Narrow", className: "max-w-3xl" },
  { value: "medium", label: "Medium", className: "max-w-4xl" },
  { value: "wide", label: "Wide", className: "max-w-5xl" },
];

export default function Reader() {
  const params = useParams<{ bookId: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const bookId = params.bookId;

  const [currentPage, setCurrentPage] = useState(1);
  const [isBookmarkDialogOpen, setIsBookmarkDialogOpen] = useState(false);
  const [bookmarkNote, setBookmarkNote] = useState("");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);

  // Fetch book data
  const { data: book, isLoading: bookLoading } = useQuery<Book>({
    queryKey: ["/api/books", bookId],
    enabled: !!bookId,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Fetch user preferences
  const { data: preferences } = useQuery<UserPreferencesType>({
    queryKey: ["/api/preferences"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Fetch reading progress
  const { data: progress } = useQuery<ReadingProgressType>({
    queryKey: ["/api/progress", bookId],
    enabled: !!bookId,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Fetch bookmarks
  const { data: bookmarks } = useQuery<BookmarkType[]>({
    queryKey: ["/api/bookmarks", bookId],
    enabled: !!bookId,
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Update progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async (data: { currentPage: number; progressPercentage: number; isCompleted: boolean }) => {
      return await apiRequest("POST", `/api/progress/${bookId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress", bookId] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Add bookmark mutation
  const addBookmarkMutation = useMutation({
    mutationFn: async (data: { bookId: string; pageNumber: number; note?: string }) => {
      return await apiRequest("POST", "/api/bookmarks", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks", bookId] });
      setIsBookmarkDialogOpen(false);
      setBookmarkNote("");
      toast({
        title: "Success",
        description: "Bookmark added",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add bookmark",
        variant: "destructive",
      });
    },
  });

  // Delete bookmark mutation
  const deleteBookmarkMutation = useMutation({
    mutationFn: async (bookmarkId: string) => {
      return await apiRequest("DELETE", `/api/bookmarks/${bookmarkId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks", bookId] });
      toast({
        title: "Success",
        description: "Bookmark removed",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to remove bookmark",
        variant: "destructive",
      });
    },
  });

  // Update preferences mutation
  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: Partial<UserPreferencesType>) => {
      return await apiRequest("PUT", "/api/preferences", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/preferences"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Initialize current page from progress
  useEffect(() => {
    if (progress?.currentPage) {
      setCurrentPage(progress.currentPage);
    }
  }, [progress]);

  // Calculate pages
  const words = book?.content.split(/\s+/) || [];
  const totalPages = Math.max(1, Math.ceil(words.length / WORDS_PER_PAGE));
  const startIdx = (currentPage - 1) * WORDS_PER_PAGE;
  const endIdx = Math.min(startIdx + WORDS_PER_PAGE, words.length);
  const pageContent = words.slice(startIdx, endIdx).join(" ");
  const progressPercentage = (currentPage / totalPages) * 100;

  // Check if current page is bookmarked
  const currentPageBookmark = bookmarks?.find(b => b.pageNumber === currentPage);

  // Handle page change
  const goToPage = (page: number) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
    const newProgress = (page / totalPages) * 100;
    updateProgressMutation.mutate({
      currentPage: page,
      progressPercentage: newProgress,
      isCompleted: page === totalPages,
    });
  };

  // Get reading preferences
  const fontSize = preferences?.fontSize || 16;
  const fontFamily = FONT_FAMILIES.find(f => f.value === (preferences?.fontFamily || "serif"));
  const lineSpacing = LINE_SPACINGS.find(l => l.value === (preferences?.lineSpacing || "normal"));
  const theme = THEMES.find(t => t.value === (preferences?.theme || "white"));
  const margin = MARGINS.find(m => m.value === (preferences?.pageMargin || "medium"));

  if (bookLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="space-y-4 w-full max-w-4xl px-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-2">Book not found</h2>
          <Button onClick={() => navigate("/")}>Return to Library</Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme?.bgClass} ${theme?.textClass} transition-colors`}>
      {/* Top Bar */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => navigate("/")}
              data-testid="button-back-library"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="min-w-0">
              <h1 className="font-semibold text-foreground truncate">{book.title}</h1>
              <p className="text-sm text-muted-foreground truncate">{book.author}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Sheet open={isBookmarksOpen} onOpenChange={setIsBookmarksOpen}>
              <SheetTrigger asChild>
                <Button size="icon" variant="ghost" data-testid="button-bookmarks">
                  <ListOrdered className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Bookmarks</SheetTitle>
                  <SheetDescription>
                    {bookmarks?.length || 0} saved bookmarks
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-3">
                  {bookmarks && bookmarks.length > 0 ? (
                    bookmarks.map((bookmark) => (
                      <Card key={bookmark.id} className="p-4 hover-elevate">
                        <div className="flex items-start justify-between gap-2">
                          <div
                            className="flex-1 cursor-pointer"
                            onClick={() => {
                              goToPage(bookmark.pageNumber);
                              setIsBookmarksOpen(false);
                            }}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="secondary">Page {bookmark.pageNumber}</Badge>
                            </div>
                            {bookmark.note && (
                              <p className="text-sm text-muted-foreground mt-2">{bookmark.note}</p>
                            )}
                          </div>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteBookmarkMutation.mutate(bookmark.id)}
                            data-testid={`button-delete-bookmark-${bookmark.id}`}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </Card>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No bookmarks yet
                    </p>
                  )}
                </div>
              </SheetContent>
            </Sheet>

            <Sheet open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <SheetTrigger asChild>
                <Button size="icon" variant="ghost" data-testid="button-settings">
                  <Settings className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Reading Settings</SheetTitle>
                  <SheetDescription>
                    Customize your reading experience
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  <div className="space-y-2">
                    <Label>Font Size: {fontSize}px</Label>
                    <Slider
                      value={[fontSize]}
                      onValueChange={([value]) => updatePreferencesMutation.mutate({ fontSize: value })}
                      min={14}
                      max={24}
                      step={1}
                      data-testid="slider-font-size"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Font Family</Label>
                    <Select
                      value={preferences?.fontFamily || "serif"}
                      onValueChange={(value) => updatePreferencesMutation.mutate({ fontFamily: value })}
                    >
                      <SelectTrigger data-testid="select-font-family">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {FONT_FAMILIES.map((font) => (
                          <SelectItem key={font.value} value={font.value}>
                            {font.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Line Spacing</Label>
                    <Select
                      value={preferences?.lineSpacing || "normal"}
                      onValueChange={(value) => updatePreferencesMutation.mutate({ lineSpacing: value })}
                    >
                      <SelectTrigger data-testid="select-line-spacing">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LINE_SPACINGS.map((spacing) => (
                          <SelectItem key={spacing.value} value={spacing.value}>
                            {spacing.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Theme</Label>
                    <Select
                      value={preferences?.theme || "white"}
                      onValueChange={(value) => updatePreferencesMutation.mutate({ theme: value })}
                    >
                      <SelectTrigger data-testid="select-theme">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {THEMES.map((themeOption) => (
                          <SelectItem key={themeOption.value} value={themeOption.value}>
                            {themeOption.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Page Margins</Label>
                    <Select
                      value={preferences?.pageMargin || "medium"}
                      onValueChange={(value) => updatePreferencesMutation.mutate({ pageMargin: value })}
                    >
                      <SelectTrigger data-testid="select-margin">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MARGINS.map((marginOption) => (
                          <SelectItem key={marginOption.value} value={marginOption.value}>
                            {marginOption.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 pb-2">
          <Progress value={progressPercentage} className="h-0.5" />
        </div>
      </div>

      {/* Reading Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className={`${margin?.className} mx-auto`}>
          <div
            className={`prose prose-lg max-w-none ${fontFamily?.className} ${lineSpacing?.className}`}
            style={{ fontSize: `${fontSize}px` }}
          >
            <p className="whitespace-pre-wrap" data-testid="text-page-content">
              {pageContent}
            </p>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-12 pt-8 border-t border-border">
            <Button
              variant="outline"
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage === 1}
              data-testid="button-prev-page"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>

            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground" data-testid="text-page-number">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                size="icon"
                variant={currentPageBookmark ? "default" : "outline"}
                onClick={() => {
                  if (currentPageBookmark) {
                    deleteBookmarkMutation.mutate(currentPageBookmark.id);
                  } else {
                    setIsBookmarkDialogOpen(true);
                  }
                }}
                data-testid="button-toggle-bookmark"
              >
                {currentPageBookmark ? (
                  <BookmarkCheck className="w-4 h-4" />
                ) : (
                  <Bookmark className="w-4 h-4" />
                )}
              </Button>
            </div>

            <Button
              variant="outline"
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage === totalPages}
              data-testid="button-next-page"
            >
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Bookmark Dialog */}
      <Dialog open={isBookmarkDialogOpen} onOpenChange={setIsBookmarkDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Bookmark</DialogTitle>
            <DialogDescription>
              Save your place on page {currentPage} with an optional note
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="bookmark-note">Note (optional)</Label>
              <Textarea
                id="bookmark-note"
                placeholder="Add a note about this page..."
                value={bookmarkNote}
                onChange={(e) => setBookmarkNote(e.target.value)}
                rows={4}
                data-testid="input-bookmark-note"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsBookmarkDialogOpen(false);
                setBookmarkNote("");
              }}
              data-testid="button-cancel-bookmark"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                addBookmarkMutation.mutate({
                  bookId: bookId!,
                  pageNumber: currentPage,
                  note: bookmarkNote || undefined,
                });
              }}
              disabled={addBookmarkMutation.isPending}
              data-testid="button-save-bookmark"
            >
              {addBookmarkMutation.isPending ? "Saving..." : "Save Bookmark"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
