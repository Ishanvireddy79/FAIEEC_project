import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Bookmark, Star, Settings, Library, TrendingUp } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-chart-2/5" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-primary/10 border border-primary/20">
                <BookOpen className="w-6 h-6 text-primary" />
                <span className="text-lg font-semibold text-primary">ReadFlow</span>
              </div>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 tracking-tight">
              Your Personal Digital
              <br />
              <span className="text-primary">Reading Experience</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed">
              Manage your e-book library, track reading progress, and enjoy a seamless reading 
              experience across all your devices with powerful customization options.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => window.location.href = "/api/login"}
                className="text-base px-8 py-6 min-h-12"
                data-testid="button-login"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Start Reading
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-base px-8 py-6 min-h-12"
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Everything You Need for Digital Reading
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A comprehensive e-reader platform built with modern technology and user-centric design
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Library className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Library Management
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Organize your entire digital book collection with search, filtering, and categorization features.
              </p>
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-chart-2/10 flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-chart-2" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Progress Tracking
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Automatically track your reading progress with visual indicators and completion statistics.
              </p>
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-chart-4/10 flex items-center justify-center mb-4">
                <Bookmark className="w-6 h-6 text-chart-4" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Smart Bookmarks
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Save your place across multiple books with notes and quick access to bookmarked pages.
              </p>
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-chart-5/10 flex items-center justify-center mb-4">
                <Star className="w-6 h-6 text-chart-5" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Favorites Collection
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Mark your favorite books and create personalized collections for quick access.
              </p>
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Settings className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Reading Customization
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Personalize font size, family, spacing, themes, and margins for optimal reading comfort.
              </p>
            </CardContent>
          </Card>

          <Card className="border-card-border">
            <CardContent className="p-6">
              <div className="w-12 h-12 rounded-md bg-chart-2/10 flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-chart-2" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">
                Responsive Reader
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Enjoy a beautiful reading experience optimized for desktop, tablet, and mobile devices.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-muted/30 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="text-center">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Ready to Transform Your Reading?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Join ReadFlow today and experience the future of digital reading
            </p>
            <Button
              size="lg"
              onClick={() => window.location.href = "/api/login"}
              className="text-base px-8 py-6 min-h-12"
              data-testid="button-cta-login"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Get Started Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
