import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Book, ReadingProgress } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BookOpen, Clock, CheckCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function History() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch reading history
  const { data: historyData, isLoading } = useQuery<{
    history: (ReadingProgress & { book: Book })[];
  }>({
    queryKey: ["/api/history"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  const history = historyData?.history || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Reading History</h1>
        <p className="text-muted-foreground">
          Track your reading progress and recently accessed books
        </p>
      </div>

      {/* History List */}
      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="border-card-border">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <Skeleton className="w-20 h-28" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-2/3" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-4 w-1/3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : history.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Clock className="w-16 h-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">No reading history yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            Start reading books from your library and they'll appear here
          </p>
          <Button onClick={() => navigate("/")} data-testid="button-go-library">
            Browse Library
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((item) => (
            <Card
              key={item.id}
              className="border-card-border hover-elevate active-elevate-2 cursor-pointer"
              onClick={() => navigate(`/reader/${item.bookId}`)}
              data-testid={`card-history-${item.id}`}
            >
              <CardContent className="p-6">
                <div className="flex gap-6">
                  <div className="w-20 h-28 flex-shrink-0 bg-muted rounded-md overflow-hidden">
                    {item.book.coverImageUrl ? (
                      <img
                        src={item.book.coverImageUrl}
                        alt={item.book.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <BookOpen className="w-8 h-8 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div className="min-w-0">
                        <h3 className="font-semibold text-card-foreground mb-1 truncate">
                          {item.book.title}
                        </h3>
                        <p className="text-sm text-muted-foreground truncate">
                          {item.book.author}
                        </p>
                      </div>
                      {item.isCompleted && (
                        <Badge className="flex-shrink-0 bg-chart-2 text-white">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completed
                        </Badge>
                      )}
                    </div>
                    <div className="space-y-2 mt-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          {item.isCompleted
                            ? "Finished reading"
                            : `Page ${item.currentPage} of ${item.book.totalPages}`}
                        </span>
                        <span className="text-muted-foreground">
                          {Math.round(item.progressPercentage)}%
                        </span>
                      </div>
                      <Progress value={item.progressPercentage} className="h-2" />
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Last read {formatDistanceToNow(new Date(item.lastReadAt!), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
