import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Book } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BookOpen, Star, BookMarked } from "lucide-react";

export default function Favorites() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch favorite books
  const { data: favoritesData, isLoading } = useQuery<{
    favorites: (Book & {
      progress?: { currentPage: number; progressPercentage: number; isCompleted: boolean };
    })[];
  }>({
    queryKey: ["/api/favorites"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  // Remove from favorites mutation
  const removeFavoriteMutation = useMutation({
    mutationFn: async (bookId: string) => {
      return await apiRequest("DELETE", `/api/favorites/${bookId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/library"] });
      toast({
        title: "Success",
        description: "Removed from favorites",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive",
      });
    },
  });

  const favorites = favoritesData?.favorites || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Favorite Books</h1>
        <p className="text-muted-foreground">
          {favorites.length} {favorites.length === 1 ? "book" : "books"} in your favorites
        </p>
      </div>

      {/* Favorites Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="border-card-border">
              <CardContent className="p-0">
                <Skeleton className="aspect-[2/3] w-full rounded-t-md" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : favorites.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Star className="w-16 h-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">No favorites yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            Mark books as favorites from your library to see them here
          </p>
          <Button onClick={() => navigate("/")} data-testid="button-go-library">
            Browse Library
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {favorites.map((book) => (
            <Card
              key={book.id}
              className="border-card-border hover-elevate active-elevate-2 cursor-pointer group overflow-visible"
              data-testid={`card-favorite-${book.id}`}
            >
              <CardContent className="p-0">
                <div
                  className="relative aspect-[2/3] bg-muted rounded-t-md overflow-hidden"
                  onClick={() => navigate(`/reader/${book.id}`)}
                >
                  {book.coverImageUrl ? (
                    <img
                      src={book.coverImageUrl}
                      alt={book.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-muted-foreground" />
                    </div>
                  )}
                  <Button
                    size="icon"
                    variant="secondary"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFavoriteMutation.mutate(book.id);
                    }}
                    data-testid={`button-unfavorite-${book.id}`}
                  >
                    <Star className="w-4 h-4 fill-chart-4 text-chart-4" />
                  </Button>
                </div>
                <div className="p-4 space-y-2" onClick={() => navigate(`/reader/${book.id}`)}>
                  <h3 className="font-semibold text-card-foreground line-clamp-2 leading-snug">
                    {book.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-1">{book.author}</p>
                  {book.genre && (
                    <Badge variant="secondary" className="text-xs">
                      {book.genre}
                    </Badge>
                  )}
                  {book.progress && (
                    <div className="space-y-1 pt-2">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>
                          {book.progress.isCompleted ? "Completed" : `${Math.round(book.progress.progressPercentage)}%`}
                        </span>
                        {!book.progress.isCompleted && book.totalPages > 0 && (
                          <span>
                            Page {book.progress.currentPage}/{book.totalPages}
                          </span>
                        )}
                      </div>
                      <Progress value={book.progress.progressPercentage} className="h-1" />
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full min-h-8"
                  onClick={() => navigate(`/reader/${book.id}`)}
                  data-testid={`button-read-${book.id}`}
                >
                  <BookMarked className="w-4 h-4 mr-1" />
                  {book.progress?.currentPage ? "Continue" : "Read"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
