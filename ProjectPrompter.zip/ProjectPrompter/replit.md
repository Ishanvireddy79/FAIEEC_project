# ReadFlow - E-Book Reader Web Application

## Overview
A comprehensive object-oriented e-book reader web application featuring user authentication, library management, interactive reading experience, and progress tracking. Built with React, TypeScript, Express, and PostgreSQL.

## Project Architecture

### Tech Stack
- **Frontend**: React, TypeScript, Wouter (routing), TanStack Query (data fetching)
- **Backend**: Express.js, Node.js, TypeScript
- **Database**: PostgreSQL (via Replit's built-in database)
- **Authentication**: Replit Auth with DatabaseStorage for session persistence
- **UI Components**: Shadcn UI, Radix UI, Tailwind CSS
- **ORM**: Drizzle ORM

### Database Schema
- **users**: User profiles with Replit Auth integration
- **books**: User's book library with metadata and content
- **bookmarks**: Saved positions in books with optional notes
- **reading_progress**: Track current page, progress percentage, and completion status
- **favorites**: User's favorite books collection
- **user_preferences**: Reading customization settings (font, theme, spacing, margins)

## Key Features

### Authentication & Security
- Replit Auth integration with session persistence
- Multi-tenant data isolation - all operations scope by userId
- Secure API endpoints with authentication middleware
- Session management with PostgreSQL-backed storage

### Library Management
- Add/remove books to personal library
- Search books by title or author
- Filter books by genre
- Cover image support
- Progress indicators on each book card
- Favorite/unfavorite books

### Interactive Reader
- Paginated reading experience (300 words per page)
- Chapter navigation with page numbers
- Bookmark system with notes
- Reading progress auto-save
- Customization options:
  - Font size (12-24px)
  - Font family (Merriweather Serif, Inter Sans, JetBrains Mono)
  - Line spacing (Compact, Normal, Relaxed)
  - Themes (White, Sepia, Dark, Black)
  - Page margins (Narrow, Medium, Wide)

### Progress Tracking
- Automatic reading progress updates
- Visual progress bars
- Reading history with timestamps
- Completion status tracking
- Continue reading from last position

### Navigation
- Responsive sidebar navigation
- Library, Favorites, and History pages
- User profile display
- Theme toggle (light/dark mode)
- Logout functionality

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Initiate login
- `GET /api/logout` - Logout user

### Books
- `GET /api/library` - Get all user books with progress and favorites
- `GET /api/books/:bookId` - Get single book (ownership verified)
- `POST /api/books` - Create new book
- `DELETE /api/books/:bookId` - Delete book (ownership verified)

### Bookmarks
- `GET /api/bookmarks/:bookId` - Get bookmarks for a book
- `POST /api/bookmarks` - Create bookmark
- `DELETE /api/bookmarks/:bookmarkId` - Delete bookmark (ownership verified)

### Reading Progress
- `GET /api/progress/:bookId` - Get reading progress
- `POST /api/progress/:bookId` - Update reading progress
- `GET /api/history` - Get reading history

### Favorites
- `GET /api/favorites` - Get favorite books
- `POST /api/favorites` - Add to favorites
- `DELETE /api/favorites/:bookId` - Remove from favorites

### User Preferences
- `GET /api/preferences` - Get user preferences
- `PUT /api/preferences` - Update user preferences

## File Structure

### Backend
- `server/index.ts` - Express server setup
- `server/routes.ts` - API route definitions
- `server/storage.ts` - Database operations with IStorage interface
- `server/replitAuth.ts` - Replit Auth configuration
- `server/db.ts` - Database connection
- `shared/schema.ts` - Drizzle schema definitions

### Frontend
- `client/src/App.tsx` - Main app with routing and auth
- `client/src/pages/Library.tsx` - Book library grid
- `client/src/pages/Reader.tsx` - Interactive reader
- `client/src/pages/Favorites.tsx` - Favorite books
- `client/src/pages/History.tsx` - Reading history
- `client/src/pages/Landing.tsx` - Landing page
- `client/src/components/app-sidebar.tsx` - Navigation sidebar
- `client/src/hooks/useAuth.ts` - Authentication hook

## Design System
- Color scheme: Primary (blue), Chart colors for accents
- Typography: Merriweather for reading, Inter for UI
- Responsive design: Mobile-first approach
- Dark mode support with theme toggle
- Apple Books-inspired clean aesthetic

## Development

### Running the Application
```bash
npm run dev
```
This starts both the Express backend (port 5000) and Vite frontend development server.

### Database Operations
```bash
npm run db:push  # Push schema changes to database
```

## Security Considerations
- All data operations verify userId ownership at storage layer
- No cross-tenant data access possible
- Session persistence in PostgreSQL
- Authentication required for all API endpoints (except landing page)

## User Preferences
Default reading preferences:
- Font Size: 16px
- Font Family: Serif (Merriweather)
- Line Spacing: Normal
- Theme: White
- Page Margin: Medium

Preferences persist across sessions and are automatically loaded in the reader.

## Recent Changes
- Implemented multi-tenant security with userId scoping on all operations
- Added ownership verification for book and bookmark deletion
- Fixed data layer to enforce security at storage level
- All API endpoints now properly verify user ownership before operations
