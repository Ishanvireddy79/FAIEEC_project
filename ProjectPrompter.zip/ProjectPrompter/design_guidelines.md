# E-Book Reader Application - Design Guidelines

## Design Approach

**Selected Approach**: Design System - Drawing from Apple Books' clean reading experience and Notion's organizational clarity

**Key Design Principles**:
- Reading-first: Minimize distractions, maximize content focus
- Intelligent hierarchy: Clear distinction between library management and reading modes
- Comfort & customization: Prioritize eye comfort and personalization
- Familiar patterns: Use established e-reader conventions for intuitive navigation

---

## Core Design Elements

### A. Color Palette

**Light Mode**:
- Background: 0 0% 98% (warm off-white for reduced eye strain)
- Surface: 0 0% 100% (cards, modals)
- Primary: 215 85% 45% (deep blue for trust and focus)
- Text Primary: 220 15% 15%
- Text Secondary: 220 10% 45%
- Border: 220 10% 90%
- Accent (sparingly): 160 60% 45% (teal for bookmarks/progress)

**Dark Mode**:
- Background: 220 15% 8% (deep charcoal)
- Surface: 220 12% 12% (elevated surfaces)
- Primary: 215 75% 55% (lighter blue)
- Text Primary: 220 5% 95%
- Text Secondary: 220 5% 65%
- Border: 220 10% 20%
- Accent: 160 50% 50%

### B. Typography

**Font Families**:
- Interface: 'Inter', system-ui, sans-serif
- Reading: 'Merriweather', Georgia, serif (warm, optimized for extended reading)
- Monospace: 'JetBrains Mono' (for code blocks in technical books)

**Type Scale**:
- Display (Library Headers): text-4xl font-bold (36px)
- Heading 1 (Book Titles): text-2xl font-semibold (24px)
- Heading 2 (Chapter Titles): text-xl font-semibold (20px)
- Body (Reading Content): text-base leading-relaxed (16px, 1.75 line-height)
- Small (Metadata): text-sm (14px)
- Caption: text-xs (12px)

### C. Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16** for consistent rhythm
- Component padding: p-4, p-6
- Section spacing: py-8, py-12, py-16
- Card gaps: gap-4, gap-6
- Reading margins: px-8 to px-16 (desktop)

**Grid System**:
- Library grid: `grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5`
- Maximum content width: max-w-7xl for library, max-w-4xl for reader

### D. Component Library

**Navigation**:
- Top navbar: Fixed position with logo, search, user profile
- Sidebar (Library): Collapsible navigation with Library, Favorites, History, Settings
- Reader toolbar: Minimal floating controls (chapter nav, bookmark, settings)

**Library View Components**:
- Book cards: Vertical cards with cover image, title, author, progress bar
- Cover aspect ratio: 2:3 (standard book proportion)
- Hover effect: Subtle elevation (shadow-lg), scale-105
- Grid layout with consistent gap-6

**Reader Interface**:
- Clean canvas: White/dark background with only content visible
- Chapter sidebar: Collapsible table of contents (left side)
- Reading progress: Thin progress bar at top (2px height)
- Page controls: Previous/Next buttons at screen edges (semi-transparent, appear on hover)
- Bookmark button: Floating top-right corner

**Forms & Inputs**:
- Search bar: Rounded-full with icon, border-2 focus state
- Text inputs: Rounded-lg, border, focus:ring-2
- Buttons: Primary (bg-primary), Secondary (variant outline), Ghost (text only)
- All inputs maintain dark mode compatibility

**Data Display**:
- Reading progress: Linear progress bars with percentage
- Statistics: Card-based metrics (Books Read, Hours Spent, Current Streak)
- Recent activity: Timeline-style list with timestamps
- Bookmarks: Chip-style tags with page numbers

**Overlays**:
- Settings panel: Slide-in drawer from right with customization options
- Book details modal: Centered modal with cover, description, metadata
- Add book form: Multi-step modal with file upload

### E. Reading Customization Panel

Font size controls: Slider from 14px to 24px
Font family selector: 3-4 serif/sans-serif options
Background themes: Sepia, White, Dark, Black
Line spacing: Compact, Normal, Relaxed
Margin controls: Narrow, Medium, Wide

### F. Animations

**Minimal & Purposeful**:
- Page transitions: Gentle fade (200ms)
- Book card hover: Smooth scale-105 transform (150ms)
- Drawer/modal: Slide-in (300ms ease-out)
- Progress updates: Smooth width transitions (400ms)
- NO scroll-triggered animations
- NO decorative background animations

---

## Images

**Book Covers**: Real or placeholder book covers throughout library grid
**Empty States**: Illustrated empty state for "No books yet" with friendly graphic
**User Avatar**: Circular profile image in navbar
**NO Hero Image**: This is a web application, not a marketing page

---

## Responsive Behavior

**Mobile (< 768px)**:
- Single column library grid
- Hamburger menu for sidebar
- Full-width reader with bottom navigation
- Swipe gestures for page turning

**Tablet (768px - 1024px)**:
- 2-3 column library grid
- Persistent sidebar (can collapse)
- Optimized reader width

**Desktop (> 1024px)**:
- 4-5 column library grid
- Fixed sidebar navigation
- Centered reader with comfortable line length