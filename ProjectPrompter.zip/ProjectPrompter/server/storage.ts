import {
  users,
  books,
  bookmarks,
  readingProgress,
  favorites,
  userPreferences,
  type User,
  type UpsertUser,
  type Book,
  type InsertBook,
  type Bookmark,
  type InsertBookmark,
  type ReadingProgress,
  type InsertReadingProgress,
  type Favorite,
  type InsertFavorite,
  type UserPreferences,
  type InsertUserPreferences,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql as drizzleSql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Book operations
  getBook(id: string, userId: string): Promise<Book | undefined>;
  getBooksByUser(userId: string): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;
  deleteBook(id: string, userId: string): Promise<void>;

  // Bookmark operations
  getBookmarksByBook(userId: string, bookId: string): Promise<Bookmark[]>;
  createBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  deleteBookmark(id: string, userId: string): Promise<void>;

  // Reading Progress operations
  getProgress(userId: string, bookId: string): Promise<ReadingProgress | undefined>;
  upsertProgress(progress: InsertReadingProgress): Promise<ReadingProgress>;
  getRecentProgress(userId: string): Promise<ReadingProgress[]>;

  // Favorites operations
  getFavoritesByUser(userId: string): Promise<Favorite[]>;
  createFavorite(favorite: InsertFavorite): Promise<Favorite>;
  deleteFavorite(userId: string, bookId: string): Promise<void>;
  isFavorite(userId: string, bookId: string): Promise<boolean>;

  // User Preferences operations
  getPreferences(userId: string): Promise<UserPreferences | undefined>;
  upsertPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Book operations
  async getBook(id: string, userId: string): Promise<Book | undefined> {
    const [book] = await db
      .select()
      .from(books)
      .where(and(eq(books.id, id), eq(books.userId, userId)));
    return book;
  }

  async getBooksByUser(userId: string): Promise<Book[]> {
    return await db.select().from(books).where(eq(books.userId, userId));
  }

  async createBook(book: InsertBook): Promise<Book> {
    const [newBook] = await db.insert(books).values(book).returning();
    return newBook;
  }

  async deleteBook(id: string, userId: string): Promise<void> {
    await db
      .delete(books)
      .where(and(eq(books.id, id), eq(books.userId, userId)));
  }

  // Bookmark operations
  async getBookmarksByBook(userId: string, bookId: string): Promise<Bookmark[]> {
    return await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.userId, userId), eq(bookmarks.bookId, bookId)))
      .orderBy(desc(bookmarks.createdAt));
  }

  async createBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const [newBookmark] = await db.insert(bookmarks).values(bookmark).returning();
    return newBookmark;
  }

  async deleteBookmark(id: string, userId: string): Promise<void> {
    await db
      .delete(bookmarks)
      .where(and(eq(bookmarks.id, id), eq(bookmarks.userId, userId)));
  }

  // Reading Progress operations
  async getProgress(userId: string, bookId: string): Promise<ReadingProgress | undefined> {
    const [progress] = await db
      .select()
      .from(readingProgress)
      .where(and(eq(readingProgress.userId, userId), eq(readingProgress.bookId, bookId)));
    return progress;
  }

  async upsertProgress(progressData: InsertReadingProgress): Promise<ReadingProgress> {
    // Check if progress exists
    const existing = await this.getProgress(progressData.userId, progressData.bookId);
    
    if (existing) {
      // Update existing progress
      const [progress] = await db
        .update(readingProgress)
        .set({
          currentPage: progressData.currentPage,
          progressPercentage: progressData.progressPercentage,
          isCompleted: progressData.isCompleted,
          lastReadAt: new Date(),
          updatedAt: new Date(),
        })
        .where(and(
          eq(readingProgress.userId, progressData.userId),
          eq(readingProgress.bookId, progressData.bookId)
        ))
        .returning();
      return progress;
    } else {
      // Insert new progress
      const [progress] = await db
        .insert(readingProgress)
        .values(progressData)
        .returning();
      return progress;
    }
  }

  async getRecentProgress(userId: string): Promise<ReadingProgress[]> {
    return await db
      .select()
      .from(readingProgress)
      .where(eq(readingProgress.userId, userId))
      .orderBy(desc(readingProgress.lastReadAt))
      .limit(20);
  }

  // Favorites operations
  async getFavoritesByUser(userId: string): Promise<Favorite[]> {
    return await db
      .select()
      .from(favorites)
      .where(eq(favorites.userId, userId))
      .orderBy(desc(favorites.createdAt));
  }

  async createFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [newFavorite] = await db.insert(favorites).values(favorite).returning();
    return newFavorite;
  }

  async deleteFavorite(userId: string, bookId: string): Promise<void> {
    await db
      .delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.bookId, bookId)));
  }

  async isFavorite(userId: string, bookId: string): Promise<boolean> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.bookId, bookId)));
    return !!favorite;
  }

  // User Preferences operations
  async getPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [preferences] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId));
    return preferences;
  }

  async upsertPreferences(preferencesData: InsertUserPreferences): Promise<UserPreferences> {
    const [preferences] = await db
      .insert(userPreferences)
      .values(preferencesData)
      .onConflictDoUpdate({
        target: userPreferences.userId,
        set: {
          ...preferencesData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return preferences;
  }
}

export const storage = new DatabaseStorage();
