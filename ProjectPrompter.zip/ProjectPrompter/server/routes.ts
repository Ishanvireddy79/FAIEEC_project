import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBookSchema, insertBookmarkSchema, insertReadingProgressSchema, insertFavoriteSchema, insertUserPreferencesSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Library endpoint - get all books with progress and favorite status
  app.get("/api/library", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const books = await storage.getBooksByUser(userId);
      
      // Enrich books with progress and favorite status
      const enrichedBooks = await Promise.all(
        books.map(async (book) => {
          const progress = await storage.getProgress(userId, book.id);
          const isFavorite = await storage.isFavorite(userId, book.id);
          
          return {
            ...book,
            progress: progress ? {
              currentPage: progress.currentPage,
              progressPercentage: progress.progressPercentage,
              isCompleted: progress.isCompleted,
            } : undefined,
            isFavorite,
          };
        })
      );

      res.json({ books: enrichedBooks });
    } catch (error) {
      console.error("Error fetching library:", error);
      res.status(500).json({ message: "Failed to fetch library" });
    }
  });

  // Get single book
  app.get("/api/books/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      const book = await storage.getBook(bookId, userId);
      
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  // Create book
  app.post("/api/books", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertBookSchema.parse({ ...req.body, userId });
      
      const book = await storage.createBook(validatedData);
      res.json(book);
    } catch (error) {
      console.error("Error creating book:", error);
      res.status(400).json({ message: "Failed to create book" });
    }
  });

  // Delete book
  app.delete("/api/books/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      
      await storage.deleteBook(bookId, userId);
      res.json({ message: "Book deleted successfully" });
    } catch (error) {
      console.error("Error deleting book:", error);
      res.status(500).json({ message: "Failed to delete book" });
    }
  });

  // Get bookmarks for a book
  app.get("/api/bookmarks/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      
      const bookmarks = await storage.getBookmarksByBook(userId, bookId);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  // Create bookmark
  app.post("/api/bookmarks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertBookmarkSchema.parse({ ...req.body, userId });
      
      const bookmark = await storage.createBookmark(validatedData);
      res.json(bookmark);
    } catch (error) {
      console.error("Error creating bookmark:", error);
      res.status(400).json({ message: "Failed to create bookmark" });
    }
  });

  // Delete bookmark
  app.delete("/api/bookmarks/:bookmarkId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookmarkId } = req.params;
      
      await storage.deleteBookmark(bookmarkId, userId);
      res.json({ message: "Bookmark deleted successfully" });
    } catch (error) {
      console.error("Error deleting bookmark:", error);
      res.status(500).json({ message: "Failed to delete bookmark" });
    }
  });

  // Get reading progress for a book
  app.get("/api/progress/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      
      const progress = await storage.getProgress(userId, bookId);
      res.json(progress || null);
    } catch (error) {
      console.error("Error fetching progress:", error);
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  // Update reading progress
  app.post("/api/progress/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      
      const validatedData = insertReadingProgressSchema.parse({
        ...req.body,
        userId,
        bookId,
      });
      
      const progress = await storage.upsertProgress(validatedData);
      res.json(progress);
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(400).json({ message: "Failed to update progress" });
    }
  });

  // Get reading history
  app.get("/api/history", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progressRecords = await storage.getRecentProgress(userId);
      
      // Enrich with book data
      const history = await Promise.all(
        progressRecords.map(async (progress) => {
          const book = await storage.getBook(progress.bookId, userId);
          return {
            ...progress,
            book,
          };
        })
      );

      res.json({ history });
    } catch (error) {
      console.error("Error fetching history:", error);
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  // Get favorites
  app.get("/api/favorites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const favoriteRecords = await storage.getFavoritesByUser(userId);
      
      // Enrich with book data and progress
      const favorites = await Promise.all(
        favoriteRecords.map(async (favorite) => {
          const book = await storage.getBook(favorite.bookId, userId);
          const progress = await storage.getProgress(userId, favorite.bookId);
          
          return {
            ...book,
            progress: progress ? {
              currentPage: progress.currentPage,
              progressPercentage: progress.progressPercentage,
              isCompleted: progress.isCompleted,
            } : undefined,
          };
        })
      );

      res.json({ favorites });
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  // Add to favorites
  app.post("/api/favorites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertFavoriteSchema.parse({ ...req.body, userId });
      
      const favorite = await storage.createFavorite(validatedData);
      res.json(favorite);
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(400).json({ message: "Failed to add favorite" });
    }
  });

  // Remove from favorites
  app.delete("/api/favorites/:bookId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { bookId } = req.params;
      
      await storage.deleteFavorite(userId, bookId);
      res.json({ message: "Removed from favorites" });
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  // Get user preferences
  app.get("/api/preferences", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let preferences = await storage.getPreferences(userId);
      
      // Create default preferences if none exist
      if (!preferences) {
        preferences = await storage.upsertPreferences({
          userId,
          fontSize: 16,
          fontFamily: "serif",
          lineSpacing: "normal",
          theme: "white",
          pageMargin: "medium",
        });
      }
      
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  // Update user preferences
  app.put("/api/preferences", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get existing preferences or defaults
      let existingPrefs = await storage.getPreferences(userId);
      if (!existingPrefs) {
        existingPrefs = {
          userId,
          fontSize: 16,
          fontFamily: "serif",
          lineSpacing: "normal",
          theme: "white",
          pageMargin: "medium",
        } as any;
      }
      
      const validatedData = insertUserPreferencesSchema.parse({
        userId,
        fontSize: req.body.fontSize ?? existingPrefs.fontSize,
        fontFamily: req.body.fontFamily ?? existingPrefs.fontFamily,
        lineSpacing: req.body.lineSpacing ?? existingPrefs.lineSpacing,
        theme: req.body.theme ?? existingPrefs.theme,
        pageMargin: req.body.pageMargin ?? existingPrefs.pageMargin,
      });
      
      const preferences = await storage.upsertPreferences(validatedData);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating preferences:", error);
      res.status(400).json({ message: "Failed to update preferences" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
